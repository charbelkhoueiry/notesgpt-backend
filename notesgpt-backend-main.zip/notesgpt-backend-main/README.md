# notesgpt-backend
git init
git add .
git commit -m "Initial backend commit"
git branch -M main
git remote add origin https://github.com/charbelkhoueiry/notesgpt-backend.git
git push -u origin main
